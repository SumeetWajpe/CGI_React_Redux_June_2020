import React from "react";
import logo from "./logo.svg";
import "./App.css";
import ListOfProducts from "./listofproducts.component";
import { MyFunctionalComponent } from "./functional.component";
import { Counter } from "./counter.hooks";
import PostsComponent from "./posts.useEffect";
import { BrowserRouter, Route, Switch,Redirect, Link } from "react-router-dom";
import PostDetailsComponent from "./postdetails.component";

// Container component -> composed of other components !
// Presentational Components -> html elements

class App extends React.Component {
  render() {
    return (
      <div>
        <BrowserRouter>

         

           <nav className="navbar navbar-inverse">
  <div className="container-fluid">
    <div className="navbar-header">
      <Link className="navbar-brand" to="/">Online Shopping</Link>
    </div>
    <ul className="nav navbar-nav">
      <li><Link to="/">Shopping Cart</Link></li>
      <li><Link to="/posts">Posts</Link> </li>
      <li><Link to="/func">Functional Component</Link> </li>
      <li><Link to="/counter">Counter</Link> </li>
    </ul>
  </div>
</nav>
         
          <Switch>
            <Route path="/" exact component={ListOfProducts}></Route>
            <Route path="/posts" component={PostsComponent}></Route>
            <Route path="/postdetails/:id" component={PostDetailsComponent}></Route>
            <Route path="/counter" component={Counter}></Route>           
            <Route
              path="/func"
              render={() => (
                <MyFunctionalComponent title="Dynamic creation !" />
              )}
            ></Route>
            <Route path="**" render={()=> <Redirect to="/" />} />
          </Switch>
        </BrowserRouter>
      </div>
    );
  }
}

export default App;
