import React from 'react';

export default class MessageComponent extends React.Component{
    render(){
    return <h2> {this.props.msg}</h2>
    }
}

export function Add(x,y){
    return x + y;
}

export const PI = 3.14;



