import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

// jquery, fetch , axios
export const PostsComponent = (props) => {
    var [posts, setPosts] = useState([]);

    useEffect(() => {
        axios.get('https://jsonplaceholder.typicode.com/posts').then(function (response) {
            // handle success
            //console.log(response.data);
            setPosts(response.data);
        })
            .catch(function (error) {
                // handle error
                console.log(error);
            });
    }, []);
    return (

        <div>
            <div className="jumbotron">
                <h1 >All Posts !</h1>
            </div>
            <ul>
                {posts.map(p => <li key={p.id}> <Link to={"/postdetails/"+p.id}>{p.title}</Link> </li>)}
            </ul>

        </div>
    )
}

export default PostsComponent;