const INCREMENT_LIKES='INCREMENT_LIKES';
// Action creator !
export function IncrementLikes(){
    return {type:INCREMENT_LIKES};
}
export function DeleteAProduct(){
    return {type:'DELETE_PRODUCT'};
}
export function AddAProduct(){
    return {type:'ADD_PRODUCT'};
}
export function DeleteAPost(){
    return {type:'DELETE_POST'};
}