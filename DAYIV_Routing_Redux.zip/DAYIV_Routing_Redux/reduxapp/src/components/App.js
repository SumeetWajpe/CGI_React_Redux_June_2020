import React from 'react';


function App(props) {
  console.log(props);
  return (
    <div>
      <h1> App Component </h1>
    </div>
  );
}

export default App;
