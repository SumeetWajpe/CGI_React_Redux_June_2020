import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
import * as AllActions from '../actions/actions';
import App from './App';

// pls map store data as props
function mapStateToProps(storeData){ // storedata made available by Provider
    return{
        allProducts:storeData.products,
        allPosts:storeData.posts
    }
}
// pls map actions as props
function mapDispatchToProps(dispatcher){
    return bindActionCreators(AllActions,dispatcher);
}

export var WrapperApp = connect(mapStateToProps,mapDispatchToProps)(App);// function currying 


