export function posts(defStore = [], action) {
  switch (action.type) {
    case "DELETE_POST":
      console.log("Within Posts reducer !");
      console.log(action);
      return defStore;
    default:
      return defStore;
  }
}
