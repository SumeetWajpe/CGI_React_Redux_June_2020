export function products(defStore = [], action) {
  switch (action.type) {
    case "INCREMENT_LIKES":
      console.log("Within products reducer !");
      console.log(action);
      return defStore; // new Store data !
    case "DELETE_PRODUCT":
      console.log("Within products reducer !");
      console.log(action);
      return defStore; // new Store data !
    default:
      return defStore;
  }
}
