import {posts} from './posts.reducer';
import {products}from './products.reducer';
import {combineReducers} from 'redux';

export var rootReducer = combineReducers({
    posts,products
});