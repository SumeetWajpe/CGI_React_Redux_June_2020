import React from "react";
import logo from "./logo.svg";
import "./App.css";
import ListOfProducts from './listofproducts.component';
import { MyFunctionalComponent } from "./functional.component";
import { Counter } from "./counter.hooks";
import PostsComponent from "./posts.useEffect";

// Container component -> composed of other components !
// Presentational Components -> html elements

class App extends React.Component {
  render() {
    // return <ListOfProducts />
    // return <MyFunctionalComponent title="My Functional Component !"/>
    // return <Counter />
    return <PostsComponent/>
  }
}

export default App;
