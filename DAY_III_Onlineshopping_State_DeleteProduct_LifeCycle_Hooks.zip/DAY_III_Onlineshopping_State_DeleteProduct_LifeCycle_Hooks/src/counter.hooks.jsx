import React, { useState } from 'react';
// State Hook !
export function Counter() {
  // Declare a new state variable, which we'll call "count"
  const [count, setCount] = useState(0);//["Hello",function()]
  var [age,setAge] = useState(18);

  return (
    <div>
      <p>You clicked {count} times</p>
      <p>Your age {age} </p>
      <button onClick={() => setCount(count + 1)}>
        Click me
      </button>
      <button onClick={() => setAge(age + 10)}>
        Click me
      </button>
    </div>
  );
}