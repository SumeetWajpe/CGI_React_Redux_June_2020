// import React from 'react';

// // 1. Can't use state  - but can useState() hook
// // 2. render()
// // 3. Can't use LifeCycle Methods !  - but can use useEffect() hook
// export function MyFunctionalComponent(){
//         return <h1> Functional Component !</h1>
// }

import React from 'react'

export const MyFunctionalComponent = (props) => {
    return(
        <div>
            <h1>{props.title}</h1>
        </div>
    )
}

export default MyFunctionalComponent