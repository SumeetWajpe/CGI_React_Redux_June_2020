import React from 'react';
import Product from './product.component';

export default class ListOfProducts extends React.Component {
    constructor(props){
        super(props);
        this.state = {products : [{
            id: 1,
            title: "Laptop",
            price: 50000,
            quantity: 100,
            rating: 4,
            ImageUrl: "https://www.lenovo.com/medias/lenovo-laptop-ideapad-c340-14-amd-hero.png?context=bWFzdGVyfHJvb3R8MjQyMzg2fGltYWdlL3BuZ3xoMGIvaGViLzk5MTUxMzg1Mzk1NTAucG5nfDIyM2E3YjY1ZWI2MTk3NzdhM2QxZjQxYWQzMDA2ZjViNmFmOWIzY2E1MTM3MGM3NDg5YzM2ZDBkYmFiYTgwN2Y",
            likes: 100
        }, {
            id: 2,
            title: "OLED TV",
            price: 25000,
            quantity: 0,
            rating: 3.5,
            ImageUrl: "https://www.pngkey.com/png/full/280-2808973_shop-our-experts-love-range-of-oled-tvs.png",
            likes: 500
        }, {
            id: 3,
            title: "Desktop",
            price: 10000,
            quantity: 200,
            rating: 3,
            ImageUrl: "https://www.pngmart.com/files/7/Desktop-Computer-Transparent-Background.png",
            likes: 200
        }, {
            id: 4,
            title: "Mobile",
            price: 20000,
            quantity: 1000,
            rating: 5,
            ImageUrl: "https://static.toiimg.com/photo/73078527.cms",
            likes: 400
        }, {
            id: 5,
            title: "Camera",
            price: 90000,
            quantity: 0,
            rating: 4,
            ImageUrl: "https://images-na.ssl-images-amazon.com/images/I/813CAX2%2BtQL._SL1500_.jpg",
            likes: 100
        }]}
        console.log('Within Constructor !');
    }
    componentWillMount(){
        // any biz logic & initialization
        console.log('Within componentWillMount !');
    }
    componentDidMount(){
        // ensures DOM is ready !
        // AJAX + timers + intergrate with diff frameworks
        console.log('Within componentDidMount !');
    }
    shouldComponentUpdate(){
        // return true | false ;
        console.log('Within shouldComponentUpdate !');
        if(arguments[1].products.length ==0){
            return false;
        }        
        return true;
    }
    componentWillUpdate(){ // deprecated !
        console.log('Within componentWillUpdate !');
        //console.log(this.state);
    }
    componentDidUpdate(){
        console.log('Within componentDidUpdate !');
    }

    DeleteHandlerFromParent(theId){
        // biz logic 
        let newProductList = this.state.products.filter(p=>p.id !== theId);
        this.setState({products:newProductList});
    }
    render() {  
        console.log('Render called !');  
       // console.log(this.state);
        var allProductsToBeDisplayed = this.state.products.map(p =>
             <Product productdetails={p}
             key={p.id}
             DeleteHandler={(theId)=>this.DeleteHandlerFromParent(theId)}
             />)
        return (
            <div>
                <h1 className="jumbotron">Online Shopping</h1>
                <div className="row">
                    {allProductsToBeDisplayed}
                </div>

            </div>
        );

    }
}