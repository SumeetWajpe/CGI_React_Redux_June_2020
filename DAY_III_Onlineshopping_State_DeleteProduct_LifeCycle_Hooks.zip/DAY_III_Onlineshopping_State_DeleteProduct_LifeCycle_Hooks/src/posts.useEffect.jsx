import React,{useEffect, useState} from 'react';
import axios from 'axios';

// jquery, fetch , axios
export const PostsComponent = (props) => {
    var [posts,setPosts] = useState([]);

    useEffect(()=>{
        axios.get('https://jsonplaceholder.typicode.com/posts').then(function (response) {
            // handle success
            //console.log(response.data);
            setPosts(response.data);
          })
          .catch(function (error) {
            // handle error
            console.log(error);
          });
    },[]);
    return(
        
        <div>
            <h1>All Posts !</h1>
            <ul>
                {posts.map(p=><li key={p.id}>{p.title}</li>)}
            </ul>

        </div>
    )
}

export default PostsComponent;