import React from 'react';
import "./product.component.css";

export default class Product extends React.Component {
    constructor(props) {
        super(props);
        this.state = { count: this.props.productdetails.likes,age:18 };// private for every component
    }
    IncrementLikesHandler() {
        //this.props.productdetails.likes;// props are readonly !
        //this.state.count++;// state is immutable !
        this.setState({ count: this.state.count + 1 });//-> {count:101,age:18} // merge
    }
    componentWillUnmount(){
        // clean up
        console.log('within componentWillUnmount');
    }

    render() {
       
        return (
            <div className="col-md-4">
                <div className="productStyle">
                    <h2>{this.props.productdetails.title}</h2>
                    <img src={this.props.productdetails.ImageUrl}
                        height="200px" width="200px" />
                    <h5>Price : {this.props.productdetails.price}</h5>
                    <h5>Rating : {this.props.productdetails.rating}</h5>
                    <h5>Quantity : {this.props.productdetails.quantity}</h5>
                    {/* <button className="btn btn-primary" 
                    onClick={this.IncrementLikesHandler.bind(this)}>
                        <span className="glyphicon glyphicon-thumbs-up">
                        </span>
                &nbsp;
                {this.props.productdetails.likes}
                    </button> */}

                    <button className="btn btn-primary"
                        onClick={() => this.IncrementLikesHandler()}>
                        <span className="glyphicon glyphicon-thumbs-up">
                        </span>
                &nbsp;
                {this.state.count}
                    </button>
                    <button className="btn btn-danger" 
                    onClick={()=>this.props.DeleteHandler(this.props.productdetails.id)}>
                        <span className="glyphicon glyphicon-trash">

                        </span>
                    </button>
                </div>
            </div>
        )
    }
}