import React from 'react';

export default class Product extends React.Component {

    render() {
        return <div>
            <h2>{this.props.productdetails.title}</h2>
            <img src={this.props.productdetails.ImageUrl}
                height="200px" width="200px" />
            <h5>Price : {this.props.productdetails.price}</h5>
            <h5>Rating : {this.props.productdetails.rating}</h5>
            <h5>Quantity : {this.props.productdetails.quantity}</h5>
            <button className="btn btn-primary">
                {this.props.productdetails.likes}
            </button>
        </div>
    }
}