import renderer from 'react-test-renderer';
import React from 'react';
import App from './App';

describe('Test Suite for Snapshot testing for App Component',()=>{
    it('app snapshot',()=>{
     var tree = renderer.create(<App/>).toJSON();
     expect(tree).toMatchSnapshot();
    });
  })