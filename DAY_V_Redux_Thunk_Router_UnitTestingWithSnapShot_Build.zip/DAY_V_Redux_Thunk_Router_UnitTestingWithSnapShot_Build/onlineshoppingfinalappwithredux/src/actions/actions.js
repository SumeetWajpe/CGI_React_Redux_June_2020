import axios from "axios";

const INCREMENT_LIKES = "INCREMENT_LIKES";
// Action creator !
export function IncrementLikes(theId) {
  return { type: INCREMENT_LIKES, theId };
}
export function DeleteAProduct(theId) {
  return { type: "DELETE_PRODUCT", theId };
}
export function AddAProduct() {
  return { type: "ADD_PRODUCT" };
}
export function DeleteAPost() {
  return { type: "DELETE_POST" };
}
export function FetchAllProducts(response){
    return {type:'FETCH_PRODUCTS',productsdata:response.data}
}
export function FetchAllProductsASYNC() {
  return (dispatch) => {
    axios
      .get("./productlist.json")
      .then((response) => dispatch(FetchAllProducts(response)));
  };
  // async action to fetch data
}
