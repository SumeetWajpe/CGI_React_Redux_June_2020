import React from "react";
import ListOfProducts from "./listofproducts.component";
import PostsComponent from "./posts.useEffect";
import { BrowserRouter, Route, Switch,Redirect, Link } from "react-router-dom";
import PostDetailsComponent from "./postdetails.component";

function App(props) {
  return (
    <div>
      {/* <ListOfProducts {...props} /> */}
      <BrowserRouter>
        <nav className="navbar navbar-inverse">
          <div className="container-fluid">
            <div className="navbar-header">
              <Link className="navbar-brand" to="/">
                Online Shopping
              </Link>
            </div>
            <ul className="nav navbar-nav">
              <li>
                <Link to="/">Shopping Cart</Link>
              </li>
              <li>
                <Link to="/posts">Posts</Link>{" "}
              </li>
             
            </ul>
          </div>
        </nav>

        <Switch>
          <Route path="/" exact render={()=><ListOfProducts {...props} />}></Route>         
          <Route path="/posts" exact render={()=><PostsComponent {...props} />}></Route>         
          <Route path="/postdetails/:id" render={(routerprops)=><PostDetailsComponent {...props} {...routerprops} />}></Route>
         
          <Route path="**" render={() => <Redirect to="/" />} />
        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
