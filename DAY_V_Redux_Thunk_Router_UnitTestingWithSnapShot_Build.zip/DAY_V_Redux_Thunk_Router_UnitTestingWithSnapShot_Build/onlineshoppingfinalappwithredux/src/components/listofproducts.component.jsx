import React from 'react';
import Product from './product.component';

export default class ListOfProducts extends React.Component {  
    componentDidMount(){
        this.props.FetchAllProductsASYNC();
    }    
    render() {         
        var allProductsToBeDisplayed = this.props.allProducts.map(p =>
             <Product {...this.props} productdetails={p} key={p.id} />)
        return (
            <div>
                <h1 className="jumbotron">Online Shopping</h1>
                <div className="row">
                    {allProductsToBeDisplayed}
                </div>
            </div>
        );
    }
}