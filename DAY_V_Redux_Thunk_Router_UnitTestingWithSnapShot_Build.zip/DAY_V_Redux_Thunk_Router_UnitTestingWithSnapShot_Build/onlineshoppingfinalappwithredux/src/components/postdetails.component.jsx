import React from 'react';

export const PostDetailsComponent = (props) => {
    
    const {match:{params}} = props;
    
    return(
        <div>
            <h1>Post Details for {params.id}</h1>
        </div>
    )
}

export default PostDetailsComponent