var index;
export function products(defStore = [], action) {
  switch (action.type) {
    case "INCREMENT_LIKES":      
      index = defStore.findIndex(p=>p.id == action.theId);
      // ?? return a new array of products with the specific product likes been incremented !
      return [
        ...defStore.slice(0,index),
        {...defStore[index],likes:defStore[index].likes+1},
        ...defStore.slice(index+1)
      ] // new Store data !
    case "DELETE_PRODUCT":
      index = defStore.findIndex(p=>p.id == action.theId);     
      return [
        ...defStore.slice(0,index),        
        ...defStore.slice(index+1)
      ] // new Store data !
      case "FETCH_PRODUCTS":
        console.log('Within FETCH_PRODUCTS');
        return action.productsdata;
    default:
      return defStore;
  }
}
