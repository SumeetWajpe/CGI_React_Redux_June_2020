import { rootReducer } from "../reducers/rootReducer"
import {createStore,applyMiddleware} from 'redux';
import thunk from 'redux-thunk';

// var storeData = {
//     products:[],
//     posts:[{id:1,title:'First Post ! '}]
// }
// createStore(reducer,storedata) !  -> redux
//export var store = createStore(rootReducer,storeData,window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__());
export var store = createStore(rootReducer,applyMiddleware(thunk));


